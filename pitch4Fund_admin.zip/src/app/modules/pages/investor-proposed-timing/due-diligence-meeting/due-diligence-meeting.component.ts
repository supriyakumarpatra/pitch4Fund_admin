import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-due-diligence-meeting',
  templateUrl: './due-diligence-meeting.component.html',
  styleUrls: ['./due-diligence-meeting.component.css']
})
export class DueDiligenceMeetingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
