import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pitch-meeting',
  templateUrl: './pitch-meeting.component.html',
  styleUrls: ['./pitch-meeting.component.css']
})
export class PitchMeetingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
